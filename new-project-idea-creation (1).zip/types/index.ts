import type React from "react"
// Core application types
export type TaskActivityCallback = (taskId: string, taskName: string, activityText: string) => void

export type TaskSwitchCallback = (taskId: string | number) => void

export type SubtaskSwitchCallback = (taskId: string | number | null) => void

export interface ChatMode {
  mode: "master" | "task"
}

export interface TaskChatProps {
  taskId?: string | null
  subtaskId?: string | null
  onSwitchTask?: TaskSwitchCallback
  onSwitchSubtask?: SubtaskSwitchCallback
  onTaskActivity?: TaskActivityCallback
}

export interface MasterChatProps {
  onSwitchTask: (taskId: string) => void
}

export interface MasterChatRef {
  addTaskActivity: (taskId: string, taskName: string, activityText: string) => void
}

export interface ProjectContextProps {
  projectId: string
}

export interface TaskListProps {
  projectStage?: "ideation" | "development"
}

export interface ResizableLayoutProps {
  leftContent: React.ReactNode
  rightContent: React.ReactNode
  initialLeftWidth: number
  minLeftWidth: number
  maxLeftWidth: number
  minRightWidth: number
  leftPadding: number
  rightPadding: number
}

export interface ChatToggleProps {
  onToggle: (mode: string) => void
  currentMode: string
}

// URL and navigation types
export interface URLParams {
  task?: string | null
  subtask?: string | null
}

export interface ProjectPageParams {
  projectId: string
}

// Enhanced loading states with granular operations
export interface LoadingStates {
  // Project-level loading
  project: boolean
  projectValidation: boolean

  // Task-related loading
  tasks: boolean
  taskCreation: boolean
  taskUpdate: boolean
  taskStatusUpdate: boolean
  taskDeletion: boolean

  // Subtask-related loading
  subtasks: boolean
  subtaskCreation: boolean
  subtaskUpdate: boolean
  subtaskStatusUpdate: boolean

  // Message-related loading
  messages: boolean
  messageCreation: boolean
  aiResponse: boolean

  // File-related loading
  files: boolean
  fileUpload: boolean
  fileDownload: boolean

  // Database operations
  databaseConnection: boolean
  dataSync: boolean

  // UI operations
  chatSwitch: boolean
  taskSwitch: boolean
  subtaskSwitch: boolean
}

// Loading operation types for better organization
export type LoadingOperation = keyof LoadingStates

// Loading context for components
export interface LoadingContextType {
  loadingStates: LoadingStates
  setLoading: (operation: LoadingOperation, loading: boolean) => void
  isAnyLoading: () => boolean
  isOperationLoading: (operation: LoadingOperation) => boolean
}

// Error types
export interface AppError {
  message: string
  code?: string
  operation?: LoadingOperation
  details?: unknown
  timestamp?: Date
}

// Component state types
export interface SidebarState {
  expanded: boolean
  hovered: boolean
}

export interface TaskChatState {
  expanded: boolean
  activeSubtask: string | null
  comment: string
}

// Event types
export interface SwitchTaskEvent extends CustomEvent {
  detail: {
    taskId: string
  }
}

// Loading component props
export interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg"
  text?: string
  operation?: LoadingOperation
}

export interface LoadingOverlayProps {
  visible: boolean
  text?: string
  operation?: LoadingOperation
}

// Progress tracking
export interface OperationProgress {
  operation: LoadingOperation
  progress: number // 0-100
  message?: string
  startTime: Date
}
