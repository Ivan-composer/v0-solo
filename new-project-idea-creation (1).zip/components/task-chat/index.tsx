"use client"

import React, { useState, useRef, useCallback } from "react"
import { ChevronUp, ChevronDown } from "lucide-react"
import { cn } from "@/utils/cn"
import { updateTaskStatus } from "@/lib/database"
import { MarkdownRenderer } from "@/components/ui/markdown-renderer"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { LoadingOverlay } from "@/components/ui/loading-overlay"
import { useLoadingStates } from "@/hooks/useLoadingStates"
import type { TaskChatProps, TaskChatState } from "@/types"

// Import our custom hooks
import { useTaskData } from "./hooks/useTaskData"
import { useTaskMessages } from "./hooks/useTaskMessages"
import { useScrollManager } from "./hooks/useScrollManager"

// Import components
import TaskHeader from "./TaskHeader"
import TaskQueue from "./TaskQueue"
import SubtaskList from "./SubtaskList"
import MessageList from "./MessageList"
import QuickActions from "./QuickActions"
import MessageInput from "./MessageInput"
import NextTaskButton from "./NextTaskButton"
import ActiveSubtaskView from "./ActiveSubtaskView"

const TaskChat = React.memo<TaskChatProps>(({ taskId, subtaskId, onSwitchTask, onSwitchSubtask, onTaskActivity }) => {
  // Loading states
  const { loadingStates, setLoading, isOperationLoading } = useLoadingStates()

  // UI State with proper typing
  const [state, setState] = useState<TaskChatState>({
    expanded: false,
    activeSubtask: subtaskId || null,
    comment: "",
  })

  // Refs with proper typing
  const inputRef = useRef<HTMLInputElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  const taskHeaderRef = useRef<HTMLDivElement>(null)

  // Custom hooks
  const { currentTask, subtasks, taskQueue, taskProgress, currentTaskPosition, loading, reloadSubtasks, loadTaskData } =
    useTaskData(taskId)

  const effectiveTaskId = state.activeSubtask || taskId
  const { messages, isLoading, sendMessage } = useTaskMessages(effectiveTaskId, currentTask)

  const { isScrolledUp, scrollToBottom } = useScrollManager(contentRef, messagesEndRef, [messages])

  // Sync subtaskId prop with internal state
  React.useEffect(() => {
    if (subtaskId !== state.activeSubtask) {
      setState((prev) => ({ ...prev, activeSubtask: subtaskId || null }))
    }
  }, [subtaskId, state.activeSubtask])

  // Notify parent when activeSubtask changes
  React.useEffect(() => {
    if (onSwitchSubtask && state.activeSubtask !== subtaskId) {
      onSwitchSubtask(state.activeSubtask)
    }
  }, [state.activeSubtask, subtaskId, onSwitchSubtask])

  // Derived state
  const activeSubtaskData = React.useMemo(() => {
    if (!state.activeSubtask) return null
    const foundSubtask = subtasks.find((s) => s.id === state.activeSubtask)
    return foundSubtask || null
  }, [state.activeSubtask, subtasks])

  const taskHeaderHeight = React.useMemo(() => {
    return taskHeaderRef.current ? taskHeaderRef.current.offsetHeight + (state.expanded ? 200 : 0) : 0
  }, [state.expanded, loading])

  const hasSubtaskMessages = messages.length > 0 && state.activeSubtask !== null

  // Callbacks
  const handleToggleExpand = useCallback(() => {
    setState((prev) => ({ ...prev, expanded: !prev.expanded }))
  }, [])

  const handleCloseQueue = useCallback(() => {
    setState((prev) => ({ ...prev, expanded: false }))
  }, [])

  const handleSubtaskClick = useCallback(
    async (subtaskId: string) => {
      setLoading("subtaskSwitch", true)
      const newActiveSubtask = state.activeSubtask === subtaskId ? null : subtaskId
      setState((prev) => ({ ...prev, activeSubtask: newActiveSubtask }))

      if (contentRef.current) {
        contentRef.current.scrollTop = 0
      }

      // Simulate brief loading for smooth UX
      setTimeout(() => setLoading("subtaskSwitch", false), 150)
    },
    [state.activeSubtask, setLoading],
  )

  const handleSendMessage = useCallback(
    async (text: string) => {
      if (!text.trim() || !currentTask) return

      setLoading("messageCreation", true)
      setState((prev) => ({ ...prev, comment: "" }))

      // Create activity text based on context
      let activityText = text
      if (state.activeSubtask && activeSubtaskData) {
        activityText = `Message in subtask "${activeSubtaskData.title}": ${text.substring(0, 50)}${text.length > 50 ? "..." : ""}`
      }

      try {
        // Send the message using our custom hook
        await sendMessage(text)

        // Notify parent about activity
        if (onTaskActivity && taskId) {
          onTaskActivity(taskId, currentTask.title, activityText)
        }
      } finally {
        setLoading("messageCreation", false)
      }
    },
    [currentTask, state.activeSubtask, activeSubtaskData, taskId, onTaskActivity, sendMessage, setLoading],
  )

  const handleExecute = useCallback(
    async (withComment = false) => {
      if (!taskId) return

      if (withComment) {
        setState((prev) => ({ ...prev, comment: "Execute, but don't forget this: " }))
        setTimeout(() => {
          if (inputRef.current) {
            inputRef.current.focus()
            const length = inputRef.current.value.length
            inputRef.current.setSelectionRange(length, length)
          }
        }, 0)
      } else {
        await handleSendMessage("Execute")
      }
    },
    [taskId, handleSendMessage],
  )

  const handleMarkAsDone = useCallback(
    async (subtaskId?: string) => {
      if (!taskId || !currentTask) return

      const operation = subtaskId ? "subtaskStatusUpdate" : "taskStatusUpdate"
      setLoading(operation, true)

      try {
        if (subtaskId) {
          const subtaskToMarkDone = subtasks.find((s) => s.id === subtaskId)
          if (!subtaskToMarkDone) return

          await updateTaskStatus(subtaskId, "completed")

          const activityText = `Subtask "${subtaskToMarkDone.title}" marked as done`
          if (onTaskActivity) {
            onTaskActivity(taskId, currentTask.title, activityText)
          }

          // Find the next subtask and make it active
          const currentIndex = subtasks.findIndex((s) => s.id === subtaskId)
          if (currentIndex !== -1 && currentIndex < subtasks.length - 1) {
            const nextSubtask = subtasks[currentIndex + 1]
            if (nextSubtask.status !== "completed") {
              // Only activate if not already completed
              await updateTaskStatus(nextSubtask.id, "active")
              setState((prev) => ({ ...prev, activeSubtask: nextSubtask.id }))
              if (onTaskActivity) {
                onTaskActivity(taskId, currentTask.title, `Subtask "${nextSubtask.title}" activated`)
              }
            }
          } else {
            // If no more subtasks, deactivate current subtask view
            setState((prev) => ({ ...prev, activeSubtask: null }))
          }

          setLoading("subtasks", true)
          await reloadSubtasks() // Reload subtasks to reflect status changes
          setLoading("subtasks", false)
        } else {
          await updateTaskStatus(currentTask.id, "completed")

          const activityText = `Task "${currentTask.title}" marked as done`
          if (onTaskActivity) {
            onTaskActivity(taskId, currentTask.title, activityText)
          }

          // Move to next task
          const currentIndex = taskQueue.findIndex((t) => t.id === currentTask.id)
          if (currentIndex < taskQueue.length - 1 && onSwitchTask) {
            const nextTask = taskQueue[currentIndex + 1]
            if (nextTask.status !== "completed") {
              // Only activate if not already completed
              await updateTaskStatus(nextTask.id, "active")
              if (onTaskActivity) {
                onTaskActivity(nextTask.id, nextTask.title, `Task "${nextTask.title}" activated`)
              }
            }
            onSwitchTask(nextTask.id)
          }

          setLoading("tasks", true)
          await loadTaskData() // Reload main task data to reflect status changes
          setLoading("tasks", false)
        }
      } catch (error) {
        console.error("Error marking task as done:", error)
      } finally {
        setLoading(operation, false)
      }
    },
    [taskId, currentTask, subtasks, taskQueue, onTaskActivity, onSwitchTask, reloadSubtasks, loadTaskData, setLoading],
  )

  const handleMarkActive = useCallback(
    async (subtaskId?: string) => {
      if (!taskId || !currentTask) return

      const operation = subtaskId ? "subtaskStatusUpdate" : "taskStatusUpdate"
      setLoading(operation, true)

      try {
        const targetId = subtaskId || taskId
        const targetTitle = subtaskId ? subtasks.find((s) => s.id === subtaskId)?.title : currentTask.title
        if (!targetTitle) return

        await updateTaskStatus(targetId, "active")

        const activityText = `${subtaskId ? "Subtask" : "Task"} "${targetTitle}" marked as active`
        if (onTaskActivity) {
          onTaskActivity(taskId, currentTask.title, activityText)
        }

        if (subtaskId) {
          setState((prev) => ({ ...prev, activeSubtask: subtaskId }))
          setLoading("subtasks", true)
          await reloadSubtasks()
          setLoading("subtasks", false)
        } else {
          setLoading("tasks", true)
          await loadTaskData()
          setLoading("tasks", false)
        }
      } catch (error) {
        console.error("Error marking task as active:", error)
      } finally {
        setLoading(operation, false)
      }
    },
    [taskId, currentTask, subtasks, onTaskActivity, reloadSubtasks, loadTaskData, setLoading],
  )

  const handleMarkOnHold = useCallback(
    async (subtaskId?: string) => {
      if (!taskId || !currentTask) return

      const operation = subtaskId ? "subtaskStatusUpdate" : "taskStatusUpdate"
      setLoading(operation, true)

      try {
        const targetId = subtaskId || taskId
        const targetTitle = subtaskId ? subtasks.find((s) => s.id === subtaskId)?.title : currentTask.title
        if (!targetTitle) return

        await updateTaskStatus(targetId, "on_hold")

        const activityText = `${subtaskId ? "Subtask" : "Task"} "${targetTitle}" marked as on hold`
        if (onTaskActivity) {
          onTaskActivity(taskId, currentTask.title, activityText)
        }

        if (subtaskId) {
          setLoading("subtasks", true)
          await reloadSubtasks()
          setLoading("subtasks", false)
        } else {
          setLoading("tasks", true)
          await loadTaskData()
          setLoading("tasks", false)
        }
      } catch (error) {
        console.error("Error marking task as on hold:", error)
      } finally {
        setLoading(operation, false)
      }
    },
    [taskId, currentTask, subtasks, onTaskActivity, reloadSubtasks, loadTaskData, setLoading],
  )

  const handleScrollToBottom = useCallback(() => {
    scrollToBottom()
  }, [scrollToBottom])

  const handleSelectTask = useCallback(
    (id: number) => {
      if (onSwitchTask) {
        onSwitchTask(String(id))
      }
    },
    [onSwitchTask],
  )

  const handleCommentChange = useCallback((comment: string) => {
    setState((prev) => ({ ...prev, comment }))
  }, [])

  // Loading state
  if (loading) {
    return (
      <div className="flex flex-col h-full">
        <div className="bg-background border-b border-gray-200 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="h-5 w-10 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-6 w-48 bg-gray-200 rounded animate-pulse"></div>
            </div>
            <div className="h-5 w-5 bg-gray-200 rounded animate-pulse"></div>
          </div>
          <div className="mt-2">
            <div className="w-full bg-gray-200 rounded-full h-1.5">
              <div className="h-1.5 rounded-full bg-gray-300 animate-pulse" style={{ width: "30%" }}></div>
            </div>
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <LoadingSpinner size="lg" text="Loading task data..." />
        </div>
      </div>
    )
  }

  // Error state
  if (!taskId || !currentTask) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6">
        <h2 className="text-xl font-semibold mb-4">Task Not Found</h2>
        <p className="text-gray-600 mb-6">
          The task you're looking for doesn't exist. Please check the task ID and try again.
        </p>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-[#FF6B6B] text-white rounded-md hover:bg-[#FF6B6B]/90 transition-colors"
        >
          Retry
        </button>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full relative">
      {/* Loading overlays for specific operations */}
      <LoadingOverlay
        visible={isOperationLoading("subtaskSwitch")}
        text="Switching subtask..."
        operation="subtaskSwitch"
      />

      {/* Task Header */}
      <div ref={taskHeaderRef}>
        <TaskHeader
          task={currentTask}
          position={currentTaskPosition}
          progress={taskProgress}
          expanded={state.expanded}
          onToggleExpand={handleToggleExpand}
        />

        {/* Task Queue */}
        {state.expanded && (
          <TaskQueue
            tasks={taskQueue}
            activeTaskId={taskId}
            onSelectTask={handleSelectTask}
            onClose={handleCloseQueue}
          />
        )}
      </div>

      {/* Fixed Subtask Header */}
      {activeSubtaskData && (
        <div
          className="sticky top-0 left-0 right-0 z-30 p-3 flex justify-between items-center cursor-pointer border-b border-gray-200 bg-background shadow-md"
          onClick={() => handleSubtaskClick(activeSubtaskData.id)}
          style={{ top: `${taskHeaderHeight}px` }}
        >
          <div className="flex items-center">
            <div
              className={cn(
                "w-6 h-6 rounded-full mr-3 flex items-center justify-center",
                activeSubtaskData.status === "completed"
                  ? "bg-[#A7D8F0] text-blue-700 hover:bg-blue-100"
                  : "bg-[#A7D8F0] text-blue-700 border border-blue-300 hover:bg-blue-100",
              )}
            >
              {activeSubtaskData.status === "completed" && "✓"}
            </div>
            <span className={cn(activeSubtaskData.status === "completed" && "text-gray-500")}>
              {activeSubtaskData.title}
            </span>
          </div>
          <ChevronUp size={18} />
        </div>
      )}

      {/* Main Content Area */}
      <div ref={contentRef} className="flex-1 overflow-auto pb-48 pt-4 no-scrollbar relative">
        {/* Subtasks loading overlay */}
        {isOperationLoading("subtasks") && (
          <div className="absolute top-4 right-4 z-20">
            <LoadingSpinner size="sm" text="Updating subtasks..." />
          </div>
        )}

        {state.activeSubtask === null ? (
          <>
            {/* Task Description with Markdown */}
            <div className="mb-6">
              <h2 className="text-lg font-semibold mb-3">{currentTask.title}</h2>
              {currentTask.description && (
                <MarkdownRenderer content={currentTask.description} className="text-gray-700" />
              )}
            </div>

            {/* Subtasks List */}
            <SubtaskList subtasks={subtasks} activeSubtask={state.activeSubtask} onSubtaskClick={handleSubtaskClick} />

            {/* Messages for the task */}
            <MessageList messages={messages} taskId={taskId} />

            {(isLoading || isOperationLoading("aiResponse")) && (
              <div className="flex justify-center my-4">
                <LoadingSpinner
                  size="md"
                  text={isOperationLoading("aiResponse") ? "AI is thinking..." : "Loading messages..."}
                />
              </div>
            )}
          </>
        ) : (
          <>
            {/* Active Subtask View */}
            <ActiveSubtaskView
              subtask={activeSubtaskData}
              messages={messages}
              hasMessages={hasSubtaskMessages}
              onExecute={handleExecute}
              isLoading={isLoading || isOperationLoading("aiResponse")}
            />
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Scroll to bottom button */}
      {isScrolledUp && (
        <button
          onClick={handleScrollToBottom}
          className="absolute left-1/2 transform -translate-x-1/2 bottom-[180px] z-20 p-2 bg-white rounded-full shadow-md hover:bg-gray-100 transition-colors border border-gray-200"
          aria-label="Scroll to bottom"
        >
          <ChevronDown size={20} className="text-gray-600" />
        </button>
      )}

      {/* Bottom Actions Area */}
      <div className="absolute bottom-0 left-0 right-0 py-4 bg-background" style={{ zIndex: 10 }}>
        <QuickActions
          onMarkAsDone={() => handleMarkAsDone(state.activeSubtask || undefined)}
          onMarkActive={() => handleMarkActive(state.activeSubtask || undefined)}
          onMarkOnHold={() => handleMarkOnHold(state.activeSubtask || undefined)}
          isLoading={{
            markAsDone: isOperationLoading("taskStatusUpdate") || isOperationLoading("subtaskStatusUpdate"),
            markActive: isOperationLoading("taskStatusUpdate") || isOperationLoading("subtaskStatusUpdate"),
            markOnHold: isOperationLoading("taskStatusUpdate") || isOperationLoading("subtaskStatusUpdate"),
          }}
        />
        <MessageInput
          ref={inputRef}
          value={state.comment}
          onChange={handleCommentChange}
          onSend={handleSendMessage}
          disabled={isOperationLoading("messageCreation")}
          isLoading={isOperationLoading("messageCreation")}
        />
        {currentTask && currentTask.status === "completed" && (
          <NextTaskButton currentTaskId={taskId} tasks={taskQueue} onSwitchTask={onSwitchTask} />
        )}
      </div>
    </div>
  )
})

TaskChat.displayName = "TaskChat"

export default TaskChat
