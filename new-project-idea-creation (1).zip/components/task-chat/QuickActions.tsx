"use client"

import { CheckCircle } from "lucide-react"
import { memo } from "react"
import { LoadingSpinner } from "@/components/ui/loading-spinner"

interface QuickActionsProps {
  onMarkAsDone: () => void
  onMarkActive: () => void
  onMarkOnHold: () => void
  isLoading?: {
    markAsDone?: boolean
    markActive?: boolean
    markOnHold?: boolean
  }
}

const QuickActions = memo(function QuickActions({
  onMarkAsDone,
  onMarkActive,
  onMarkOnHold,
  isLoading = {},
}: QuickActionsProps) {
  return (
    <div className="flex overflow-x-scroll overflow-y-hidden pb-3 space-x-2 no-scrollbar">
      <button
        className="px-3 py-1.5 bg-[#A7D8F0]/10 text-[#A7D8F0] rounded-md whitespace-nowrap hover:bg-[#A7D8F0]/20 transition-colors text-sm flex-shrink-0 flex items-center disabled:opacity-50"
        onClick={onMarkAsDone}
        disabled={isLoading.markAsDone}
      >
        {isLoading.markAsDone ? <LoadingSpinner size="sm" /> : <CheckCircle size={14} className="mr-1.5" />}
        <span className="ml-1">Mark as done</span>
      </button>

      <button
        className="px-3 py-1.5 bg-green-50 text-green-700 rounded-md whitespace-nowrap hover:bg-green-100 transition-colors text-sm flex-shrink-0 flex items-center disabled:opacity-50"
        onClick={onMarkActive}
        disabled={isLoading.markActive}
      >
        {isLoading.markActive ? <LoadingSpinner size="sm" /> : <CheckCircle size={14} className="mr-1.5" />}
        <span className="ml-1">Mark Active</span>
      </button>

      <button
        className="px-3 py-1.5 bg-yellow-50 text-yellow-700 rounded-md whitespace-nowrap hover:bg-yellow-100 transition-colors text-sm flex-shrink-0 flex items-center disabled:opacity-50"
        onClick={onMarkOnHold}
        disabled={isLoading.markOnHold}
      >
        {isLoading.markOnHold ? <LoadingSpinner size="sm" /> : <CheckCircle size={14} className="mr-1.5" />}
        <span className="ml-1">Mark On Hold</span>
      </button>
    </div>
  )
})

export default QuickActions
