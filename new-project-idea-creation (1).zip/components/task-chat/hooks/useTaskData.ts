"use client"

import { useState, useEffect, useCallback } from "react"
import { getAllTasks, getSubtasks, getTaskById, type Task } from "@/lib/database"

interface TaskData {
  currentTask: Task | null
  subtasks: Task[]
  taskQueue: Task[]
  taskProgress: number
  currentTaskPosition: string
  loading: boolean
  reloadSubtasks: () => Promise<void>
  loadTaskData: () => Promise<void>
}

export function useTaskData(taskId?: string | null): TaskData {
  const [currentTask, setCurrentTask] = useState<Task | null>(null)
  const [subtasks, setSubtasks] = useState<Task[]>([])
  const [taskQueue, setTaskQueue] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)

  const loadTaskData = useCallback(async () => {
    setLoading(true)
    try {
      const allTasks = await getAllTasks()
      setTaskQueue(allTasks)

      let task: Task | null = null
      if (taskId) {
        task = await getTaskById(taskId)
      } else {
        // If no taskId is provided, try to find the first active task
        task = allTasks.find((t) => t.status === "active") // Changed from "in_progress" to "active"
        if (!task && allTasks.length > 0) {
          // Fallback to the first task if no active task is found
          task = allTasks[0]
        }
      }

      setCurrentTask(task)

      if (task) {
        const fetchedSubtasks = await getSubtasks(task.id)
        setSubtasks(fetchedSubtasks)
      } else {
        setSubtasks([])
      }
    } catch (error) {
      console.error("Failed to load task data:", error)
    } finally {
      setLoading(false)
    }
  }, [taskId])

  const reloadSubtasks = useCallback(async () => {
    if (currentTask) {
      const fetchedSubtasks = await getSubtasks(currentTask.id)
      setSubtasks(fetchedSubtasks)
    }
  }, [currentTask])

  useEffect(() => {
    loadTaskData()
  }, [loadTaskData])

  const taskProgress = currentTask
    ? (subtasks.filter((s) => s.status === "completed").length / subtasks.length) * 100 || 0
    : 0

  const currentTaskPosition = currentTask
    ? `${taskQueue.findIndex((t) => t.id === currentTask.id) + 1} / ${taskQueue.length}`
    : "N/A"

  return {
    currentTask,
    subtasks,
    taskQueue,
    taskProgress,
    currentTaskPosition,
    loading,
    reloadSubtasks,
    loadTaskData,
  }
}
