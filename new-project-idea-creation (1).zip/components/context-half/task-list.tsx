"use client"

import { useState, useEffect, useCallback } from "react"
import { cn } from "@/utils/cn"
import { getAllTasks, getSubtasks, isTaskAvailable, type Task } from "@/lib/database"
import { BookOpen, PenTool, Code, Award, Lock, Tag, MessageSquare } from "lucide-react"
import * as PopoverPrimitive from "@radix-ui/react-popover"
import { MarkdownRenderer } from "@/components/ui/markdown-renderer"

interface TaskListProps {
  projectStage?: "ideation" | "development"
}

export default function TaskList({ projectStage = "ideation" }: TaskListProps) {
  const [viewMode, setViewMode] = useState<"map" | "list">("map")
  const [expandedTasks, setExpandedTasks] = useState<Set<string>>(new Set())
  const [tasks, setTasks] = useState<Task[]>([])
  const [subtasks, setSubtasks] = useState<{ [key: string]: Task[] }>({})
  const [loading, setLoading] = useState(true)
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null)

  const loadTasks = useCallback(async () => {
    setLoading(true)
    try {
      const tasksData = await getAllTasks()
      setTasks(tasksData)

      // Find the active task (first active task, or first available planned task)
      const activeTask = tasksData.find((t) => t.status === "active") // Changed from "in_progress" to "active"

      if (activeTask) {
        setActiveTaskId(activeTask.id)
      } else {
        // Find first available planned task
        const availableTask = tasksData.find((t) => t.status === "planned" && isTaskAvailable(t, tasksData))
        if (availableTask) {
          setActiveTaskId(availableTask.id)
        }
      }

      // Load subtasks for each task
      const subtasksData: { [key: string]: Task[] } = {}
      for (const task of tasksData) {
        subtasksData[task.id] = await getSubtasks(task.id)
      }
      setSubtasks(subtasksData)
    } catch (error) {
      console.error("Error loading tasks:", error)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadTasks()
  }, [loadTasks])

  // Updated function to use custom event instead of URL navigation
  const openTaskInChat = (taskId: string) => {
    // Dispatch a custom event to notify the parent components
    const event = new CustomEvent("switch-task", {
      detail: { taskId },
      bubbles: true, // Allow the event to bubble up through the DOM
    })
    document.dispatchEvent(event)
  }

  const handleTaskExpand = (taskId: string) => {
    const newExpanded = new Set(expandedTasks)
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId)
    } else {
      newExpanded.add(taskId)
    }
    setExpandedTasks(newExpanded)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8 h-full">
        <div className="w-12 h-12 border-4 border-gray-200 border-t-[#FF6B6B] rounded-full animate-spin"></div>
      </div>
    )
  }

  if (tasks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8">
        <div className="text-center">
          <Tag className="h-16 w-16 text-muted-foreground mb-4 mx-auto" />
          <h3 className="text-lg font-medium mb-2">No tasks found</h3>
          <p className="text-muted-foreground">
            This project doesn't have any tasks yet. Tasks will appear here once they're created.
          </p>
        </div>
      </div>
    )
  }

  const getTaskIcon = (task: Task) => {
    switch (task.type) {
      case "template":
        return <BookOpen className="w-5 h-5" />
      case "user_task":
        return <PenTool className="w-5 h-5" />
      case "tech_task":
        return <Code className="w-5 h-5" />
      default:
        return <Award className="w-5 h-5" />
    }
  }

  // Calculate progress for a task based on its subtasks
  const calculateProgress = (task: Task): number => {
    const taskSubtasks = subtasks[task.id] || []

    if (task.status === "completed" && taskSubtasks.length === 0) {
      return 100
    }
    if (taskSubtasks.length === 0) return 0

    const completedSubtasks = taskSubtasks.filter((subtask) => subtask.status === "completed").length
    return (completedSubtasks / taskSubtasks.length) * 100
  }

  // Render progress circle
  const renderProgressCircle = (progress: number, size = 80, status: string, isAvailable: boolean) => {
    const strokeWidth = 5
    const radius = size / 2 - strokeWidth / 2 - 2
    const circumference = 2 * Math.PI * radius
    const strokeDashoffset = circumference - (progress / 100) * circumference

    // Set color based on status
    let progressColor = "#9CA3AF" // Default gray
    if (status === "completed") {
      progressColor = "#A7D8F0"
    } else if (status === "active") {
      progressColor = "#FF6B6B" // Changed to FF6B6B for active tasks
    }

    // Apply opacity for on-hold tasks
    const opacity = !isAvailable && status !== "completed" ? 0.5 : 1

    return (
      <div className="absolute inset-0 flex items-center justify-center">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="absolute">
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#E5E7EB"
            strokeWidth={strokeWidth / 2}
            style={{ opacity: opacity }}
          />
          {/* Progress circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={progressColor}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
            style={{ opacity: opacity }}
            className="transition-all duration-500 ease-in-out"
          />
        </svg>
      </div>
    )
  }

  // Render a task node
  const renderTaskNode = (task: Task) => {
    const isAvailable = isTaskAvailable(task, tasks) || task.status === "completed"
    const isActiveTask = task.id === activeTaskId || task.status === "active" // Changed from "in_progress" to "active"

    const progress = calculateProgress(task)

    return (
      <div className="flex flex-col items-center relative z-10">
        {/* Task circle with Popover */}
        <PopoverPrimitive.Root>
          <PopoverPrimitive.Trigger>
            <div className="relative w-20 h-20">
              {/* Progress circle */}
              {renderProgressCircle(progress, 80, task.status, isAvailable)}

              <button
                type="button"
                className={cn(
                  "w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300 absolute",
                  "bg-white text-gray-700 shadow-md hover:shadow-lg",
                  "top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20",
                )}
                style={{
                  opacity: !isAvailable && task.status !== "completed" ? 0.5 : 1,
                }}
                disabled={!isAvailable && task.status !== "completed"}
              >
                {/* Task icon */}
                <div
                  style={{
                    color:
                      !isAvailable && task.status !== "completed"
                        ? "rgba(156, 163, 175, 0.5)" // Apply opacity for on-hold icon
                        : task.status === "completed"
                          ? "#A7D8F0" // Done tasks color
                          : isActiveTask
                            ? "#FF6B6B" // Active tasks color
                            : "#374151", // Default text color
                    opacity: !isAvailable && task.status !== "completed" ? 0.5 : 1,
                  }}
                >
                  {!isAvailable && task.status !== "completed" ? <Lock className="w-5 h-5" /> : getTaskIcon(task)}
                </div>
              </button>

              {/* Glow effect for active tasks */}
              {isActiveTask && <div className="absolute inset-0 rounded-full bg-[#FF6B6B]/10 blur-md z-0"></div>}
              {/* Glow effect for completed tasks */}
              {task.status === "completed" && (
                <div className="absolute inset-0 rounded-full bg-[#A7D8F0]/20 blur-md z-0"></div> // Enhanced glow for completed tasks
              )}
            </div>
          </PopoverPrimitive.Trigger>
          <PopoverPrimitive.Portal>
            <PopoverPrimitive.Content
              className="z-[100] max-h-[var(--radix-popover-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-lg border border-gray-200 bg-white p-4 text-gray-900 shadow-lg outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 w-[320px] max-w-[90vw]"
              side="right"
              align="start"
              sideOffset={8}
            >
              {/* Header with chat icon */}
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center">
                  <h4 className="font-semibold">{task.title}</h4>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      openTaskInChat(task.id)
                    }}
                    className="ml-2 text-gray-500 hover:text-gray-700"
                    title="Open in chat"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Task description with markdown */}
              {task.description && (
                <div className="mb-3">
                  <MarkdownRenderer content={task.description} className="text-sm text-gray-700 prose-sm" />
                </div>
              )}

              {/* Dependencies section */}
              {task.dependent_on_tasks && task.dependent_on_tasks.length > 0 && (
                <div className="mb-3">
                  <div className="text-sm font-medium text-gray-500">Dependencies:</div>
                  <div className="text-sm">
                    {task.dependent_on_tasks.map((depId) => {
                      const depTask = tasks.find((t) => t.id === depId)
                      return (
                        <div key={depId} className="flex items-center mt-1">
                          <div
                            className="w-3 h-3 rounded-full mr-2 flex-shrink-0"
                            style={{
                              backgroundColor: depTask?.status === "done" ? "#A7D8F0" : "#9CA3AF",
                            }}
                          ></div>
                          <span>{depTask?.title || `Task #${depId}`}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Subtasks section */}
              {subtasks[task.id]?.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-500">Subtasks:</div>
                  {subtasks[task.id].map((subtask) => (
                    <div key={subtask.id} className="flex items-center">
                      <div
                        className="w-4 h-4 rounded-full mr-2 flex-shrink-0"
                        style={{
                          backgroundColor:
                            subtask.status === "completed"
                              ? "#A7D8F0"
                              : subtask.status === "active" // Changed from "in_progress" to "active"
                                ? "#FF6B6B"
                                : "#D1D5DB",
                        }}
                      ></div>
                      <span className="text-sm">{subtask.title}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-gray-500">No subtasks available</div>
              )}
              <PopoverPrimitive.Arrow className="fill-white" width={11} height={5} />
            </PopoverPrimitive.Content>
          </PopoverPrimitive.Portal>
        </PopoverPrimitive.Root>

        {/* Task name below circle */}
        <div className="mt-2 text-center relative">
          <div
            className="font-medium px-3 py-1 bg-white rounded-md shadow-sm border border-gray-100"
            style={{
              opacity: !isAvailable && task.status !== "completed" ? 0.5 : 1,
            }}
          >
            {task.title}
          </div>
        </div>
      </div>
    )
  }

  // Sort tasks by ID to ensure consistent order
  const sortedTasks = tasks.sort((a, b) => a.id - b.id)

  // Generate serpentine S-curve positions like in the image
  const getSerpentinePosition = (index: number) => {
    // The pattern from your image:
    // 0: center (50%)
    // 1: right (70%)
    // 2: slightly right of center (60%)
    // 3: slightly left of center (40%)
    // 4: left (30%)
    // 5: same as 3 (40%)
    // 6: same as 2 (60%)
    // 7: same as 1 (70%)
    // 8: back to center (50%) - cycle repeats

    const positions = [50, 70, 60, 40, 30, 40, 60, 70] // percentages from left
    const cycleLength = positions.length
    const positionIndex = index % cycleLength

    return positions[positionIndex]
  }

  const renderListView = () => {
    return (
      <div className="px-4 space-y-4">
        {sortedTasks.map((task, index) => {
          const isAvailable = isTaskAvailable(task, tasks) || task.status === "completed"
          const isActiveTask = task.id === activeTaskId || task.status === "active"
          const isExpanded = expandedTasks.has(task.id)

          // Determine circle color and icon
          let circleColor = "#9CA3AF" // Default gray
          let circleIcon = null

          if (task.status === "completed") {
            circleColor = "#A7D8F0"
            circleIcon = "✓"
          } else if (isActiveTask) {
            circleColor = "#FF6B6B"
            circleIcon = "▶"
          } else if (!isAvailable) {
            circleColor = "#9CA3AF"
            circleIcon = "🔒"
          }

          const progress = calculateProgress(task)

          return (
            <div key={task.id} className="relative">
              {/* Connecting line */}
              {index < sortedTasks.length - 1 && (
                <div className="absolute left-6 top-12 w-0.5 h-8 bg-gray-300" style={{ zIndex: 1 }} />
              )}

              {/* Task card */}
              <div
                className="bg-white rounded-lg border border-gray-200 p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer relative"
                style={{
                  opacity: !isAvailable && task.status !== "completed" ? 0.5 : 1,
                  zIndex: 2,
                }}
                onClick={() => handleTaskExpand(task.id)}
              >
                <div className="flex items-start space-x-4">
                  {/* Status circle */}
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0"
                    style={{ backgroundColor: circleColor }}
                  >
                    {circleIcon}
                  </div>

                  {/* Task content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-gray-900 truncate">{task.title}</h3>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          openTaskInChat(task.id)
                        }}
                        className="text-gray-500 hover:text-gray-700 p-1"
                        title="Open in chat"
                      >
                        <MessageSquare className="w-5 h-5" />
                      </button>
                    </div>
                    {task.description && <p className="text-sm text-gray-600 mt-1 line-clamp-2">{task.description}</p>}
                  </div>
                </div>

                {/* Subtasks */}
                {isExpanded && subtasks[task.id]?.length > 0 && (
                  <div className="mt-4 pl-16 space-y-2">
                    <div className="text-sm font-medium text-gray-500">Subtasks:</div>
                    {subtasks[task.id].map((subtask) => (
                      <div key={subtask.id} className="flex items-center space-x-3">
                        <div
                          className="w-4 h-4 rounded-full flex-shrink-0"
                          style={{
                            backgroundColor:
                              subtask.status === "completed"
                                ? "#A7D8F0"
                                : subtask.status === "active"
                                  ? "#FF6B6B"
                                  : "#D1D5DB",
                          }}
                        />
                        <span className="text-sm text-gray-700">{subtask.title}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <div className="w-full h-full overflow-auto py-8">
      {/* Stage indicator with view toggle */}
      <div className="flex items-center justify-between mb-4 mx-4 bg-[#A7D8F0]/10 p-2 rounded-md">
        <div className="flex items-center">
          <Tag className="text-[#A7D8F0] mr-2" size={18} />
          <span className="text-[#A7D8F0] text-sm">Task Overview</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setViewMode("map")}
            className={cn(
              "px-3 py-1 rounded text-sm font-medium transition-colors",
              viewMode === "map" ? "bg-[#A7D8F0] text-white" : "text-[#A7D8F0] hover:bg-[#A7D8F0]/20",
            )}
          >
            Map
          </button>
          <button
            onClick={() => setViewMode("list")}
            className={cn(
              "px-3 py-1 rounded text-sm font-medium transition-colors",
              viewMode === "list" ? "bg-[#A7D8F0] text-white" : "text-[#A7D8F0] hover:bg-[#A7D8F0]/20",
            )}
          >
            List
          </button>
        </div>
      </div>

      {/* Conditional rendering based on view mode */}
      {viewMode === "map" ? (
        <div className="px-4">
          <div className="relative w-full">
            {sortedTasks.map((task, index) => {
              const leftPosition = getSerpentinePosition(index)

              return (
                <div key={task.id} className="relative w-full mb-8" style={{ minHeight: "120px" }}>
                  <div
                    className="absolute transform -translate-x-1/2"
                    style={{
                      left: `${leftPosition}%`,
                      top: "0px",
                    }}
                  >
                    {renderTaskNode(task)}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      ) : (
        renderListView()
      )}
    </div>
  )
}
