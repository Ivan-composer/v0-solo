"use client"

import { cn } from "@/utils/cn"
import type { LoadingSpinnerProps } from "@/types"

const sizeClasses = {
  sm: "w-4 h-4",
  md: "w-8 h-8",
  lg: "w-12 h-12",
}

const textSizeClasses = {
  sm: "text-sm",
  md: "text-base",
  lg: "text-lg",
}

export function LoadingSpinner({ size = "md", text, operation }: LoadingSpinnerProps) {
  return (
    <div className="flex items-center justify-center space-x-2">
      <div className={cn("border-4 border-gray-200 border-t-primary rounded-full animate-spin", sizeClasses[size])} />
      {text && <span className={cn("text-gray-600", textSizeClasses[size])}>{text}</span>}
    </div>
  )
}
