"use client"
import { LoadingSpinner } from "./loading-spinner"
import type { LoadingOverlayProps } from "@/types"

export function LoadingOverlay({ visible, text, operation }: LoadingOverlayProps) {
  if (!visible) return null

  return (
    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 max-w-sm mx-4">
        <LoadingSpinner size="lg" text={text} operation={operation} />
      </div>
    </div>
  )
}
