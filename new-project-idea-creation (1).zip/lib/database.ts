import { getSupabase } from "./supabase"

// Types based on actual database schema
export type Project = {
  id: string // UUID
  owner_id: string // UUID, FK to users.auth_id
  name: string
  description: string | null
  status: "active" | "archived"
  template_version: number
  created_at: string
  updated_at: string
}

export type Task = {
  id: string // UUID
  project_id: string // UUID, FK to projects.id
  parent_task_id: string | null // UUID, FK to tasks.id
  author_id: string // UUID, FK to users.auth_id
  type: "template" | "user_task" | "tech_task"
  title: string
  description: string | null
  status: "active" | "on_hold" | "completed" | "skipped" | "archived"
  order_index: number | null
  sprint: number | null
  summary: string | null
  metadata: any | null // JSONB
  created_at: string
  updated_at: string
}

export type Message = {
  id: string // UUID
  task_id: string // UUID, FK to tasks.id
  author_id: string | null // UUID, FK to users.auth_id (nullable for system messages)
  role: "user" | "agent" | "system" | "tool"
  content: string | null
  tool_payload: any | null // JSONB
  created_at: string
}

export type User = {
  auth_id: string // UUID, PK
  id: number // bigserial
  name: string | null
  avatar_url: string | null
  last_login: string | null
  created_at: string
  updated_at: string
}

export type File = {
  id: string // UUID
  project_id: string // UUID, FK to projects.id
  storage_path: string
  file_name: string
  mime_type: string
  version: number
  created_by: string // UUID, FK to users.auth_id
  created_at: string
  updated_at: string
  metadata: any | null // JSONB
}

// Project functions
export async function getProject(projectId: string): Promise<Project | null> {
  const supabase = getSupabase()
  const { data, error } = await supabase.from("projects").select("*").eq("id", projectId).maybeSingle()

  if (error) {
    console.error(`Error fetching project ${projectId}:`, error)
    return null
  }

  return data as Project | null
}

export async function updateProject(
  projectId: string,
  updates: { name?: string; description?: string; status?: string },
): Promise<Project | null> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("projects")
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq("id", projectId)
    .select()
    .single()

  if (error) {
    console.error(`Error updating project ${projectId}:`, error)
    return null
  }

  return data as Project
}

export async function createProject(
  name: string,
  description: string | null,
  ownerId: string,
): Promise<Project | null> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("projects")
    .insert([
      {
        name,
        description,
        owner_id: ownerId,
        status: "active",
        template_version: 1,
      },
    ])
    .select()
    .single()

  if (error) {
    console.error("Error creating project:", error)
    return null
  }

  return data as Project
}

// Task functions
export async function getAllTasks(projectId?: string): Promise<Task[]> {
  const supabase = getSupabase()
  let query = supabase.from("tasks").select("*").is("parent_task_id", null).order("order_index", { ascending: true })

  if (projectId) {
    query = query.eq("project_id", projectId)
  }

  const { data, error } = await query

  if (error) {
    console.error("Error fetching tasks:", error)
    return []
  }

  return data as Task[]
}

export async function getSubtasks(taskId: string): Promise<Task[]> {
  if (!taskId || taskId === "undefined") {
    console.warn("getSubtasks called with invalid taskId:", taskId)
    return []
  }

  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("tasks")
    .select("*")
    .eq("parent_task_id", taskId)
    .order("order_index", { ascending: true })

  if (error) {
    console.error(`Error fetching subtasks for task ${taskId}:`, error)
    return []
  }

  return data as Task[]
}

export async function getTaskById(taskId: string): Promise<Task | null> {
  if (
    !taskId ||
    taskId === "undefined" ||
    !taskId.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)
  ) {
    console.warn("getTaskById called with invalid taskId:", taskId)
    return null
  }

  const supabase = getSupabase()
  const { data, error } = await supabase.from("tasks").select("*").eq("id", taskId).maybeSingle()

  if (error) {
    console.error(`Error fetching task ${taskId}:`, error)
    return null
  }

  return data as Task | null
}

export async function createTask(
  projectId: string,
  title: string,
  description: string | null = null,
  authorId: string,
  parentTaskId: string | null = null,
  type: "template" | "user_task" | "tech_task" = "user_task",
): Promise<Task | null> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("tasks")
    .insert([
      {
        project_id: projectId,
        title,
        description,
        author_id: authorId,
        parent_task_id: parentTaskId,
        type,
        status: "on_hold",
      },
    ])
    .select()
    .single()

  if (error) {
    console.error("Error creating task:", error)
    return null
  }

  return data as Task
}

export async function updateTaskStatus(
  taskId: string,
  status: "active" | "on_hold" | "completed" | "skipped" | "archived",
): Promise<Task | null> {
  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("tasks")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", taskId)
    .select()
    .single()

  if (error) {
    console.error(`Error updating task ${taskId}:`, error)
    return null
  }

  return data as Task
}

// Message functions
export async function getMessagesForTask(taskId: string): Promise<Message[]> {
  if (
    !taskId ||
    taskId === "undefined" ||
    !taskId.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)
  ) {
    console.warn("getMessagesForTask called with invalid taskId:", taskId)
    return []
  }

  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("task_id", taskId)
    .order("created_at", { ascending: true })

  if (error) {
    console.error(`Error fetching messages for task ${taskId}:`, error)
    return []
  }

  return data as Message[]
}

export async function getMasterChatMessages(projectId?: string): Promise<Message[]> {
  // Master chat messages are not implemented yet
  return []
}

export async function createMessage(
  taskId: string,
  content: string | null,
  authorId: string | null = null,
  role: "user" | "agent" | "system" | "tool" = "user",
  toolPayload: any = null,
): Promise<Message | null> {
  if (
    !taskId ||
    taskId === "undefined" ||
    !taskId.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)
  ) {
    console.error("createMessage called with invalid taskId:", taskId)
    return null
  }

  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("messages")
    .insert([
      {
        task_id: taskId,
        content,
        author_id: authorId,
        role,
        tool_payload: toolPayload,
      },
    ])
    .select()
    .single()

  if (error) {
    console.error("Error creating message:", error)
    return null
  }

  return data as Message
}

// File functions
export async function getFilesForProject(projectId: string): Promise<File[]> {
  if (
    !projectId ||
    projectId === "undefined" ||
    !projectId.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)
  ) {
    console.warn("getFilesForProject called with invalid projectId:", projectId)
    return []
  }

  const supabase = getSupabase()
  const { data, error } = await supabase
    .from("files")
    .select("*")
    .eq("project_id", projectId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error(`Error fetching files for project ${projectId}:`, error)
    return []
  }

  return data as File[]
}

// Function to check if a task is available (all dependencies completed)
export function isTaskAvailable(task: Task, allTasks: Task[]): boolean {
  // Tasks are available if their status is not 'completed' or 'skipped'
  return task.status === "on_hold" || task.status === "active"
}
