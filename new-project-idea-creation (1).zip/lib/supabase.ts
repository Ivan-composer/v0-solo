import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client
let supabaseClient: ReturnType<typeof createClient> | null = null

export function getSupabase() {
  if (!supabaseClient) {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://example.supabase.co"
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "your-anon-key"

    supabaseClient = createClient(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: false,
      },
    })
  }

  return supabaseClient
}

export async function checkSupabaseConnection(): Promise<boolean> {
  try {
    const supabase = getSupabase()
    if (!supabase) {
      console.warn("Supabase client is not initialized.")
      return false
    }

    const { data, error } = await supabase.from("projects").select("id").limit(1)

    if (error) {
      console.error("Supabase connection error:", error.message)
      return false
    }

    return true
  } catch (error) {
    console.error("Error checking Supabase connection:", error)
    return false
  }
}
