"use client"

import { useState, useEffect, useRef, useMemo, useCallback } from "react"
import Sidebar from "@/components/sidebar"
import TaskChat from "@/components/task-chat"
import MasterChat from "@/components/master-chat"
import ProjectContext from "@/components/context-half/project-context"
import ChatToggle from "@/components/chat-toggle"
import ResizableLayout from "@/components/resizable-layout"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { LoadingOverlay } from "@/components/ui/loading-overlay"
import { getAllTasks, createTask } from "@/lib/database"
import { useLoadingStates } from "@/hooks/useLoadingStates"
import { Menu } from "lucide-react"
import { getSupabase } from "@/lib/supabase"
import { useRouter, useSearchParams } from "next/navigation"
import type { ProjectPageParams, SidebarState, AppError, MasterChatRef, SwitchTaskEvent } from "@/types"

interface ProjectPageProps {
  params: ProjectPageParams
}

export default function ProjectPage({ params }: ProjectPageProps) {
  // Loading states hook
  const { loadingStates, setLoading, isAnyLoading, isOperationLoading } = useLoadingStates()

  // State with proper types
  const [chatMode, setChatMode] = useState<"master" | "task">("task")
  const [error, setError] = useState<AppError | null>(null)
  const [sidebarState, setSidebarState] = useState<SidebarState>({
    expanded: false,
    hovered: false,
  })
  const sidebarTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const searchParams = useSearchParams()
  const router = useRouter()
  const [taskId, setTaskId] = useState<string | null>(null)
  const [subtaskId, setSubtaskId] = useState<string | null>(null)

  // Properly typed ref
  const masterChatRef = useRef<MasterChatRef | null>(null)

  // Memoized URL parameters
  const urlTaskId = useMemo(() => searchParams.get("task"), [searchParams])
  const urlSubtaskId = useMemo(() => searchParams.get("subtask"), [searchParams])

  // Initialize task and subtask from URL
  useEffect(() => {
    if (urlTaskId) {
      setTaskId(urlTaskId)
    }
    if (urlSubtaskId) {
      setSubtaskId(urlSubtaskId)
    }
  }, [urlTaskId, urlSubtaskId])

  const loadTaskId = useCallback(async () => {
    setLoading("tasks", true)
    setError(null)
    try {
      // Check that projectId is defined and not "undefined"
      if (!params.projectId || params.projectId === "undefined") {
        setError({
          message: "Invalid project ID. Please select a valid project.",
          operation: "projectValidation",
        })
        return
      }

      // First, check if there are any tasks for this project
      const tasks = await getAllTasks(params.projectId)

      if (tasks.length > 0) {
        // If we have a task ID from URL, use it; otherwise use the first active task or first task
        if (!urlTaskId) {
          const activeTask = tasks.find((t) => t.status === "active")
          const selectedTask = activeTask || tasks[0]
          setTaskId(selectedTask.id)
        }
      } else {
        // If no tasks exist, create a default task for this project
        setLoading("taskCreation", true)
        const defaultTask = await createTask(
          params.projectId,
          "Market Research",
          "Research the market to understand competitors and opportunities",
          "7d61e0ff-031a-48af-a640-3dc85b3ad69c", // Default author_id from your sample data
        )

        if (defaultTask) {
          setTaskId(defaultTask.id)

          // Create some subtasks for this task
          setLoading("subtaskCreation", true)
          await Promise.all([
            createTask(
              params.projectId,
              "Identify direct competitors",
              "Research and list main competitors in the market",
              "7d61e0ff-031a-48af-a640-3dc85b3ad69c",
              defaultTask.id,
            ),
            createTask(
              params.projectId,
              "Analyze competitor strengths and weaknesses",
              "Evaluate what competitors do well and where they fall short",
              "7d61e0ff-031a-48af-a640-3dc85b3ad69c",
              defaultTask.id,
            ),
            createTask(
              params.projectId,
              "Identify market gaps and opportunities",
              "Find areas where customer needs are not being met",
              "7d61e0ff-031a-48af-a640-3dc85b3ad69c",
              defaultTask.id,
            ),
            createTask(
              params.projectId,
              "Create a competitive positioning map",
              "Visualize where your product fits in the market",
              "7d61e0ff-031a-48af-a640-3dc85b3ad69c",
              defaultTask.id,
            ),
          ])
          setLoading("subtaskCreation", false)
        } else {
          setError({
            message: "Failed to create default task",
            operation: "taskCreation",
          })
        }
        setLoading("taskCreation", false)
      }
    } catch (error) {
      console.error("Error loading or creating tasks:", error)
      setError({
        message: "Failed to load tasks. Please try again.",
        operation: "tasks",
        details: error,
      })
    } finally {
      setLoading("tasks", false)
    }
  }, [params.projectId, urlTaskId, setLoading])

  // Check if the project exists first
  const checkProject = useCallback(async () => {
    setLoading("projectValidation", true)
    try {
      // Check that projectId is defined and not "undefined"
      if (!params.projectId || params.projectId === "undefined") {
        setError({
          message: "Invalid project ID. Please select a valid project.",
          operation: "projectValidation",
        })
        return
      }

      const supabase = getSupabase()
      setLoading("databaseConnection", true)

      // Use the correct column name 'id' instead of 'project_id'
      const { data, error: supabaseError } = await supabase
        .from("projects")
        .select("id")
        .eq("id", params.projectId)
        .single()

      setLoading("databaseConnection", false)

      if (supabaseError || !data) {
        console.error("Project not found or error:", supabaseError)
        setError({
          message: "Project not found or failed to load. Please ensure the project ID is valid.",
          operation: "projectValidation",
          details: supabaseError,
        })
        return // Exit early if project not found or error
      }

      // Project exists, now load or create tasks
      await loadTaskId()
    } catch (error) {
      console.error("Error checking project:", error)
      setError({
        message: "An unexpected error occurred while checking the project.",
        operation: "projectValidation",
        details: error,
      })
    } finally {
      setLoading("projectValidation", false)
    }
  }, [params.projectId, loadTaskId, setLoading])

  useEffect(() => {
    setLoading("project", true)
    checkProject().finally(() => {
      setLoading("project", false)
    })
  }, [checkProject, setLoading])

  // Add event listener for the custom switch-task event
  useEffect(() => {
    const handleSwitchTaskEvent = (event: Event) => {
      const customEvent = event as SwitchTaskEvent
      if (customEvent.detail && customEvent.detail.taskId) {
        setLoading("taskSwitch", true)
        // Switch to the task
        setTaskId(customEvent.detail.taskId)
        // Clear subtask when switching tasks
        setSubtaskId(null)
        // Make sure we're in task chat mode
        setChatMode("task")
        // Simulate brief loading for smooth UX
        setTimeout(() => setLoading("taskSwitch", false), 300)
      }
    }

    document.addEventListener("switch-task", handleSwitchTaskEvent)

    // Clean up the event listener when component unmounts
    return () => {
      document.removeEventListener("switch-task", handleSwitchTaskEvent)
    }
  }, [setLoading])

  // Update URL when task or subtask changes
  const updateURL = useCallback(
    (newTaskId: string | null, newSubtaskId: string | null) => {
      const newSearchParams = new URLSearchParams(searchParams.toString())

      if (newTaskId) {
        newSearchParams.set("task", newTaskId)
      } else {
        newSearchParams.delete("task")
      }

      if (newSubtaskId) {
        newSearchParams.set("subtask", newSubtaskId)
      } else {
        newSearchParams.delete("subtask")
      }

      const newURL = `/projects/${params.projectId}?${newSearchParams.toString()}`
      router.replace(newURL, { scroll: false })
    },
    [searchParams, router, params.projectId],
  )

  // Sync taskId and subtaskId with URL
  useEffect(() => {
    const currentTaskParam = searchParams.get("task")
    const currentSubtaskParam = searchParams.get("subtask")

    if (taskId !== currentTaskParam || subtaskId !== currentSubtaskParam) {
      updateURL(taskId, subtaskId)
    }
  }, [taskId, subtaskId, searchParams, updateURL])

  const handleSwitchTask = useCallback(
    (newTaskId: string | number) => {
      setLoading("taskSwitch", true)
      const taskIdString = String(newTaskId)
      setTaskId(taskIdString)
      // Clear subtask when switching to a different task
      setSubtaskId(null)
      // Simulate brief loading for smooth UX
      setTimeout(() => setLoading("taskSwitch", false), 200)
    },
    [setLoading],
  )

  const handleSwitchSubtask = useCallback(
    (newSubtaskId: string | number | null) => {
      setLoading("subtaskSwitch", true)
      const subtaskIdString = newSubtaskId ? String(newSubtaskId) : null
      setSubtaskId(subtaskIdString)
      // Simulate brief loading for smooth UX
      setTimeout(() => setLoading("subtaskSwitch", false), 150)
    },
    [setLoading],
  )

  // Handle task activity to update the master chat
  const handleTaskActivity = useCallback((taskId: string, taskName: string, activityText: string) => {
    // If masterChatRef.current exists and has the addTaskActivity method, call it
    if (masterChatRef.current && typeof masterChatRef.current.addTaskActivity === "function") {
      masterChatRef.current.addTaskActivity(taskId, taskName, activityText)
    }
  }, [])

  const handleMouseEnterSidebar = useCallback(() => {
    if (sidebarTimeoutRef.current) {
      clearTimeout(sidebarTimeoutRef.current)
      sidebarTimeoutRef.current = null
    }
    setSidebarState((prev) => ({ ...prev, hovered: true }))
  }, [])

  const handleMouseLeaveSidebar = useCallback(() => {
    sidebarTimeoutRef.current = setTimeout(() => {
      setSidebarState((prev) => ({ ...prev, hovered: false }))
    }, 300) // Delay to prevent immediate collapse
  }, [])

  const toggleSidebar = useCallback(() => {
    setSidebarState((prev) => ({ ...prev, expanded: !prev.expanded }))
  }, [])

  const handleChatModeToggle = useCallback(
    (mode: string) => {
      setLoading("chatSwitch", true)
      setChatMode(mode as "master" | "task")
      // Simulate brief loading for smooth UX
      setTimeout(() => setLoading("chatSwitch", false), 200)
    },
    [setLoading],
  )

  useEffect(() => {
    return () => {
      if (sidebarTimeoutRef.current) {
        clearTimeout(sidebarTimeoutRef.current)
      }
    }
  }, [])

  // Memoized content components
  const leftContent = useMemo(
    () => (
      <div className="flex flex-col h-full relative">
        <div className="h-[64px] p-4 border-b border-gray-200 flex justify-center items-center">
          <ChatToggle onToggle={handleChatModeToggle} currentMode={chatMode} />
        </div>

        <div className="flex-1 overflow-hidden relative">
          {/* Chat switch loading overlay */}
          <LoadingOverlay
            visible={isOperationLoading("chatSwitch")}
            text="Switching chat mode..."
            operation="chatSwitch"
          />

          {chatMode === "master" ? (
            <MasterChat
              ref={masterChatRef}
              onSwitchTask={(taskId) => {
                setTaskId(taskId)
                setSubtaskId(null)
                setChatMode("task")
              }}
            />
          ) : taskId && taskId !== "undefined" ? (
            <TaskChat
              taskId={taskId}
              subtaskId={subtaskId}
              onSwitchTask={handleSwitchTask}
              onSwitchSubtask={handleSwitchSubtask}
              onTaskActivity={handleTaskActivity}
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full p-6">
              <h2 className="text-xl font-semibold mb-4">No Tasks Available</h2>
              <p className="text-gray-600 mb-6 text-center">
                There are no tasks for this project yet. Please create a task to get started.
              </p>
              <button
                onClick={async () => {
                  if (params.projectId && params.projectId !== "undefined") {
                    setLoading("taskCreation", true)
                    const task = await createTask(
                      params.projectId,
                      "Market Research",
                      "Research the market to understand competitors and opportunities",
                      "7d61e0ff-031a-48af-a640-3dc85b3ad69c", // Default author_id from your sample data
                    )
                    if (task) setTaskId(task.id)
                    setLoading("taskCreation", false)
                  } else {
                    setError({
                      message: "Invalid project ID. Please select a valid project.",
                      operation: "taskCreation",
                    })
                  }
                }}
                disabled={isOperationLoading("taskCreation")}
                className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors disabled:opacity-50 flex items-center space-x-2"
              >
                {isOperationLoading("taskCreation") ? (
                  <>
                    <LoadingSpinner size="sm" />
                    <span>Creating...</span>
                  </>
                ) : (
                  <span>Create First Task</span>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    ),
    [
      chatMode,
      taskId,
      subtaskId,
      handleSwitchTask,
      handleSwitchSubtask,
      handleTaskActivity,
      params.projectId,
      isOperationLoading,
      setLoading,
      handleChatModeToggle,
    ],
  )

  // Memoized right content
  const rightContent = useMemo(
    () => (
      <div className="h-full flex flex-col" data-component="project-context">
        <ProjectContext projectId={params.projectId} />
      </div>
    ),
    [params.projectId],
  )

  // Enhanced loading screen with specific operation feedback
  if (isOperationLoading("project") || isOperationLoading("projectValidation")) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <LoadingSpinner size="lg" />
          <p className="mt-4 text-gray-600">
            {isOperationLoading("projectValidation") ? "Validating project..." : "Loading project..."}
          </p>
          {isOperationLoading("databaseConnection") && (
            <p className="mt-2 text-sm text-gray-500">Connecting to database...</p>
          )}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md">
          <h2 className="text-xl font-semibold text-red-700 mb-2">Error</h2>
          <p className="text-gray-700 mb-2">{error.message}</p>
          {error.operation && <p className="text-sm text-gray-500 mb-4">Operation: {error.operation}</p>}
          <div className="flex justify-center">
            <button
              onClick={() => (window.location.href = "/")}
              className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition-colors"
            >
              Go to Home
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen relative">
      {/* Global loading overlay for major operations */}
      <LoadingOverlay visible={isOperationLoading("dataSync")} text="Syncing data..." operation="dataSync" />

      {/* Sidebar trigger area */}
      <div className="fixed top-0 left-0 h-full w-2 z-20" onMouseEnter={handleMouseEnterSidebar}></div>

      {/* Sidebar - collapsed by default */}
      <div
        className={`fixed top-0 left-0 h-full z-30 transition-all duration-300 ${
          sidebarState.expanded || sidebarState.hovered ? "w-64 opacity-100" : "w-0 opacity-0 pointer-events-none"
        }`}
        onMouseLeave={handleMouseLeaveSidebar}
      >
        <div className="h-full" onClick={toggleSidebar}>
          <Sidebar />
        </div>
      </div>

      {/* Sidebar toggle button */}
      <button
        className="fixed top-4 left-4 z-40 p-2 bg-background rounded-full shadow-md hover:bg-secondary transition-colors"
        onClick={toggleSidebar}
        aria-label="Toggle sidebar"
      >
        <Menu size={20} />
      </button>

      {/* Main content area with resizable layout */}
      <div className={`flex flex-1 transition-all duration-300 ${sidebarState.expanded ? "ml-64" : "ml-0"}`}>
        <ResizableLayout
          leftContent={leftContent}
          rightContent={rightContent}
          initialLeftWidth={50}
          minLeftWidth={360} // minimum width for left panel
          maxLeftWidth={770} // updated to 770px
          minRightWidth={360} // minimum width for right panel
          leftPadding={25}
          rightPadding={45}
        />
      </div>
    </div>
  )
}
