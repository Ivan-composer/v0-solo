"use client"
import Header from "@/components/homepage/header"
import IdeaInput from "@/components/homepage/idea-input"
import TrendingIdeas from "@/components/homepage/trending-ideas"
import ProjectThumbnails from "@/components/homepage/project-thumbnails"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-1 overflow-auto p-4">
        <div className="w-full max-w-3xl mx-auto mt-6 flex justify-center">
          <div className="bg-gray-100 p-1 rounded-lg inline-flex">
            <button className="px-4 py-2 rounded-md text-sm font-medium transition-colors bg-white text-purple-600 shadow-sm">
              New Idea
            </button>
            <button className="px-4 py-2 rounded-md text-sm font-medium transition-colors text-gray-600 hover:text-gray-900">
              Existing Project
            </button>
          </div>
        </div>
        <IdeaInput />
        <TrendingIdeas />
        <ProjectThumbnails />
      </main>
    </div>
  )
}
