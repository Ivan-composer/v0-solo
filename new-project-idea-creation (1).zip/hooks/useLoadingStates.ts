"use client"

import { useState, useCallback, useMemo } from "react"
import type { LoadingStates, LoadingOperation, LoadingContextType } from "@/types"

const initialLoadingStates: LoadingStates = {
  // Project-level loading
  project: false,
  projectValidation: false,

  // Task-related loading
  tasks: false,
  taskCreation: false,
  taskUpdate: false,
  taskStatusUpdate: false,
  taskDeletion: false,

  // Subtask-related loading
  subtasks: false,
  subtaskCreation: false,
  subtaskUpdate: false,
  subtaskStatusUpdate: false,

  // Message-related loading
  messages: false,
  messageCreation: false,
  aiResponse: false,

  // File-related loading
  files: false,
  fileUpload: false,
  fileDownload: false,

  // Database operations
  databaseConnection: false,
  dataSync: false,

  // UI operations
  chatSwitch: false,
  taskSwitch: false,
  subtaskSwitch: false,
}

export function useLoadingStates(): LoadingContextType {
  const [loadingStates, setLoadingStates] = useState<LoadingStates>(initialLoadingStates)

  const setLoading = useCallback((operation: LoadingOperation, loading: boolean) => {
    setLoadingStates((prev) => ({
      ...prev,
      [operation]: loading,
    }))
  }, [])

  const isAnyLoading = useCallback(() => {
    return Object.values(loadingStates).some(Boolean)
  }, [loadingStates])

  const isOperationLoading = useCallback(
    (operation: LoadingOperation) => {
      return loadingStates[operation]
    },
    [loadingStates],
  )

  const contextValue = useMemo(
    () => ({
      loadingStates,
      setLoading,
      isAnyLoading,
      isOperationLoading,
    }),
    [loadingStates, setLoading, isAnyLoading, isOperationLoading],
  )

  return contextValue
}
